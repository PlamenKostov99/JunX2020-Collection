import javax.script.ScriptException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws ScriptException {


    }
}
